/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vote;
/**
 *
 * @author Jae
 */
public class Login {
    // variables
    private String firstName, lastName, eMail, id,password,sex,phoneNum,address;
    
    // constructor

    public Login(String firstName, String lastName, String eMail, String id, String password, String sex, String phoneNum, String address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.eMail = eMail;
        this.id = id;
        this.password = password;
        this.sex = sex;
        this.phoneNum = phoneNum;
        this.address = address;
    }
    
    
    // getter
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String geteMail() { return eMail; }
    public String getId() { return id; }

    public String getPassword() {
        return password;
    }

    public String getSex() {
        return sex;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public String getAddress() {
        return address;
    }
    
}
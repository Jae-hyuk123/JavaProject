/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package login;

import java.io.Serializable;

/**
 *
 * @author ABC
 */
public class LoginInformation implements Serializable {
    // variables
    private String firstName, lastName, email, id, sex, phoneNumber, address, age;
    
    // constructor
    public LoginInformation(String firstName, String lastName, String eMail, String id, String sex, String phoneNumber, String address, String age)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = eMail;
        this.id = id;
        this.sex = sex;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.age = age;
    }
    public LoginInformation(){
        
    }
    
    // getter
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getEmail() { return email; }
    public String getId() { return id; }
    public String getSex() { return sex; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getAddress() { return address; }
    public String getAge() { return age; } 

    //User details to be overwritten in subclasses
    public String printDetails() {
        return "First Name: "+firstName+"\nLast Name: "+lastName+"\nEmail: "+email+"\nId: "+id+"\nSex: "+sex+"\nPhone Number: "+
                phoneNumber+"\nAddress: "+address+"\nAge: "+age;
    }

}
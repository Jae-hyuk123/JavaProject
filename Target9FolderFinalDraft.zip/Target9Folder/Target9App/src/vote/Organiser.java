/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vote;

import java.io.Serializable;
import login.LoginInformation;

/**
 *
 * @author moise
 */
public class Organiser extends LoginInformation implements TurnoutPercentage, YesPercentage, NoPercentage, SpoiledPercentage, Serializable {
    //variables

    private String timeline, county;
    private int population, totalVotes, yesVotes, noVotes, spoiledVotes;

    //overloaded constructor
    public Organiser(String timeline, String county, int population, int totalVotes, int yesVotes, int noVotes, int spoiledVotes, String firstName, String lastName, String email, String id, String sex, String phoneNumber, String address, String age) {
        super(firstName, lastName, email, id, sex, phoneNumber, address, age);
        this.timeline = timeline;
        this.county = county;
        this.population = population;
        this.totalVotes = totalVotes;
        this.yesVotes = yesVotes;
        this.noVotes = noVotes;
        this.spoiledVotes = spoiledVotes;
    }

    //setters
    public void setTimeline(String timeline) {
        this.timeline = timeline;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    //getters
    public String getTimeline() {
        return timeline;
    }

    public String getCounty() {
        return county;
    }

    //Details for the organiser of the vote added to details of the vote
    @Override
    public String printDetails() {
        //Using String Buffer to get all voters details to then add it to print details
        return "Organiser: \n" + super.printDetails() + "\nVote Details: " + "\nTimeline of Vote: " + timeline + "\nCounty: " + county + "\nPopulation: "
                + population + "\nTotal votes: " + totalVotes + "\nNum of Yes:" + yesVotes
                + "\nNum of No's:" + noVotes + "\nNum of Spoiled votes:" + spoiledVotes + "\nTurnout: " + turnoutPercentage() + "\nPercentage of yes votes: "
                + yesPercentage() + "\nPercentage of no votes: " + noPercentage() + "\nPercentage of spoiled votes: " + spoiledPercentage();

    }

    //Calculate turnout percentage
    @Override
    public double turnoutPercentage() {
        if (totalVotes == 0) {
            return 0;
        }
        return (totalVotes / (double) population) * 100;
    }
    //Calculate yes votes percentage

    @Override
    public double yesPercentage() {
        if (totalVotes == 0) {
            return 0;
        }
        return (yesVotes / (double) totalVotes) * 100;
    }
    //Calculate no votes percentage

    @Override
    public double noPercentage() {
        if (totalVotes == 0) {
            return 0;
        }
        return (noVotes / (double) totalVotes) * 100;
    }

    //Calculate spoiled votes percentage
    @Override
    public double spoiledPercentage() {
        if (totalVotes == 0) {
            return 0;
        }
        return (spoiledVotes / (double) totalVotes) * 100;
    }
}

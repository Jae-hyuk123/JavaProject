/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package report;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author Jaehyuk Lim
 */
public class ReportSave {
    // variable
    private ArrayList<ReportValidation> reports = new ArrayList<>();
    
    public void addReport(ReportValidation r)
    {
        reports.add(r);
        saveReportToFile(r);
    }
    
    public void saveReportToFile(ReportValidation r)
    {
        // declare and create object
        File dataDir = new File("reports");
        
        // check if the file is existing
        if(!dataDir.exists())
        {
            dataDir.mkdirs();   // create the dircetory
        }
        
        // declare and create object
        File file = new File(dataDir, "data.txt");
        
        // append the new information to file since the second argument is true.
        try(FileWriter writer = new FileWriter(file, true))
        {
            writer.write(r.getType() + ", " + r.getCounty() + ", " + r.getDetailedAddress() + ", " + r.getDescription() + ", " + r.getPhoto() + "\n");
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "Error");
        }
        
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vote;

/**
 *
 * @author moise
 */
public class Vote {

    //variables
    private String voterNames;
    private String voterId;
    private String vote;
    private String reason;
    Vote(){
        
    }
    
    //overloaded constructor
    public Vote(String voterNames, String voterId, String vote, String reason) {
        this.voterNames = voterNames;
        this.voterId = voterId;
        this.vote = vote;
        this.reason = reason;
    }
    //setters

    public void setVoterNames(String voterNames) {
        this.voterNames = voterNames;
    }

    public void setVoterId(String voterId) {
        this.voterId = voterId;
    }

    public void setVote(String vote) {
        this.vote = vote;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

   
    //getters

    public String getVoterNames() {
        return voterNames;
    }

    public String getVoterId() {
        return voterId;
    }

    public String getVote() {
        return vote;
    }

    public String getReason() {
        return reason;
    }
    //Details of vote to be overritten in InfrastructureVote and BusinessAidVote class
    public String voteDetails(){
        return "\nvoter Names: "+voterNames+"\nId : "+voterId+"\nVote: "+vote+"\n Reason: " + reason;
    }
}
